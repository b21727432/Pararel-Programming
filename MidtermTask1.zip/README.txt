Ali Kayadibi

21727432

Reimplementation of MPI_Gather


In my midterm my task is to Reimplementation of MPI_Gather.In this task, this spesific Gather function has two stages, and at each stage a specific
communication pattern is used.At first we must have 4x4 2D Torus.In this Torus, at first stage four processes(subroots) receive messages from their neighbors.
Those four processes have four pieces of data gathered in their buffers.After first stage, three of those four processes send their data to the fourth
(globalroot) process.Finally, the target process has sixteen pieces data gathered from all.

In this reimplementation task, each process including the target process , sends their data to it's neighbor subroot by message send.In these message send
process sends it's data, number of variables to sent, type of variable, target, message tag and message comm.After sending , the subroots will receive this message
by using recv function which gives address of buffer, number of variables to receive, type of variable, rank of source, message tag, comm and status of this operation.
Subroots will store their neighbors datas.After this, each subroot will send their buffer (which has neighbor) datas, to global root.This time we will sent and 
receive buffer.Subroot will sent their buffer using send operation but this time they will give addresses of their buffers and they will send 4 datas with them.
Type will be the same, destination is globalroot, tag and comm will be given.After that global root will receive these messages and global root will store them in 
rank order.This will complete our reimplementation of MPI_Gather.

For my design desicions , i have decided to use if else blocks to select wanted processes and wanted subroots, globals root and i have decided to use senders rank
as message tag, by doing that receiver will know who sent the message.I have used malloc, realloc for memory efficiency.At the end, i have stored all the datas by
their rank order.

To execute my program, you can write mpiexec -n 16 MPIFirstTry.exe.It will return process 1 with other processes'es data.I wrote each step, each buffer ofsubroot 
and global root's buffer. 

I have used visual studio 2019,mpi.h library and command line argument to run and test my program.I am using Windows operating system. 