﻿// MPIFirstTry.cpp : Bu dosya 'main' işlevi içeriyor. Program yürütme orada başlayıp biter.
//

#include <iostream>
#include "mpi.h"
int main(int *argc, char **argv){

    /*This is where i create my 4x4 2D Torus.*/


    int commsize, rank;
    MPI_Status status;

    MPI_Init(NULL, NULL);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &commsize);

    int dims[2] = { 0, 0 };
    MPI_Dims_create(commsize, 2, dims);

    int periods[2] = { true, true };

    int reorder = true;

    MPI_Comm new_communicator;
    MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, reorder, &new_communicator);

    int my_rank;
    MPI_Comm_rank(new_communicator, &my_rank);

    int my_coords[2];
    MPI_Cart_coords(new_communicator, my_rank, 2, my_coords);

    //printf("[MPI process %d] I am located at (%d, %d).\n", my_rank, my_coords[0], my_coords[1]);
    
    /*After entering 16 in command line it will create 16 process and place them on the 4x4 2D torus.This
    is where i check if their rank or coords give correct output or not.*/

    int* buf;
    int data = my_rank;

    /*if (rank == 0) {
        MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    }

    if (rank == 1) {
        buf = (int*)malloc(2 * sizeof(int));
        buf[0] = rank;
        MPI_Recv(&buf[1], 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        printf("%d %d", buf[0], buf[1]);
    }*/

    /*if (rank == 0) {
       
    
    
    }*/

    /*I want my neighbors to send messages to subroots.I use their ranks to select them and 
    I sent message to closest subroot to them.I do this step for every process in the 4X4 2D Torus.*/


    if (rank == 0 || rank == 2 || rank == 5) {
        if (rank == 0) {
            MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        }
        if (rank == 2) {
            MPI_Send(&data, 1, MPI_INT, 1, 2, MPI_COMM_WORLD);
        }
        if (rank == 5) {
            MPI_Send(&data, 1, MPI_INT, 1, 5, MPI_COMM_WORLD);
        }
    }
    else if(rank == 3 || rank == 6 || rank == 11){
        if (rank == 3) {
            MPI_Send(&data, 1, MPI_INT, 7, 3, MPI_COMM_WORLD);
        }
        if (rank == 6) {
            MPI_Send(&data, 1, MPI_INT, 7, 6, MPI_COMM_WORLD);
        }
        if (rank == 11) {
            MPI_Send(&data, 1, MPI_INT, 7, 11, MPI_COMM_WORLD);
        }
    }
    else if (rank == 4 || rank == 9 || rank == 12) {
        if (rank == 4) {
            MPI_Send(&data, 1, MPI_INT, 8, 4, MPI_COMM_WORLD);
        }
        if (rank == 9) {
            MPI_Send(&data, 1, MPI_INT, 8, 9, MPI_COMM_WORLD);
        }
        if (rank == 12) {
            MPI_Send(&data, 1, MPI_INT, 8, 12, MPI_COMM_WORLD);
        }
    }
    else if (rank == 10 || rank == 13 || rank == 15) {
        if (rank == 10) {
            MPI_Send(&data, 1, MPI_INT, 14, 10, MPI_COMM_WORLD);
        }
        if (rank == 13) {
            MPI_Send(&data, 1, MPI_INT, 14, 13, MPI_COMM_WORLD);
        }
        if (rank == 15) {
            MPI_Send(&data, 1, MPI_INT, 14, 15, MPI_COMM_WORLD);
        }
    }
    else if (rank == 1) { 
        buf = (int*)malloc(4 * sizeof(int));
        buf[0] = rank;

        MPI_Recv(&buf[1], 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[2], 1, MPI_INT, 2, 2, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[3], 1, MPI_INT, 5, 5, MPI_COMM_WORLD, &status);

        printf("Step 1: SubRoot Process 1 : %d %d %d %d", buf[0], buf[1], buf[2], buf[3]);

        /*After getting the datas from neighbors, i store them in subroot's buffers.These buffers will send to global buffer
        to get final ranking order.*/

        //printf("BURASI %d %d %d %d BURASI", buf[0], buf[1], buf[2], buf[3]);

        /*int** arr = (int**)malloc(4 * sizeof(int*));
        for (int i = 0; i < 4; i++)
            arr[i] = (int*)malloc(4 * sizeof(int));

        arr[0] = buf;

        MPI_Recv(arr[1], 4, MPI_INT, 7, 7, MPI_COMM_WORLD, &status);
        MPI_Recv(arr[2], 4, MPI_INT, 8, 8, MPI_COMM_WORLD, &status);
        MPI_Recv(arr[3], 4, MPI_INT, 14, 14, MPI_COMM_WORLD, &status);*/

        int* arr = (int*)malloc(16 * sizeof(int));

        arr[buf[0]] = buf[0];
        arr[buf[1]] = buf[1];
        arr[buf[2]] = buf[2];
        arr[buf[3]] = buf[3];

        MPI_Recv(buf, 4, MPI_INT, 7, 7, MPI_COMM_WORLD, &status);

        arr[buf[0]] = buf[0];
        arr[buf[1]] = buf[1];
        arr[buf[2]] = buf[2];
        arr[buf[3]] = buf[3];

        MPI_Recv(buf, 4, MPI_INT, 8, 8, MPI_COMM_WORLD, &status);

        arr[buf[0]] = buf[0];
        arr[buf[1]] = buf[1];
        arr[buf[2]] = buf[2];
        arr[buf[3]] = buf[3];

        MPI_Recv(buf, 4, MPI_INT, 14, 14, MPI_COMM_WORLD, &status);

        arr[buf[0]] = buf[0];
        arr[buf[1]] = buf[1];
        arr[buf[2]] = buf[2];
        arr[buf[3]] = buf[3];

        buf = (int*)realloc(buf, sizeof(int) * 16);
        printf("\nStep 2: GlobalRoot Process 1 :");
        for (int i = 0; i < 16; i++) {
            buf[i] = arr[i];
            printf("%d ", buf[i]);
        }



        free(arr);

       /* printf("\n%d %d %d %d", arr[0][0], arr[0][1], arr[0][2], arr[0][3]);
        printf(" %d %d %d %d", arr[1][0], arr[1][1], arr[1][2], arr[1][3]);
        printf(" %d %d %d %d", arr[2][0], arr[2][1], arr[2][2], arr[2][3]);
        printf(" %d %d %d %d\n", arr[3][0], arr[3][1], arr[3][2], arr[3][3]);*/

    }
    else if (rank == 7) {
        buf = (int*)malloc(4 * sizeof(int));
        buf[0] = rank;

        MPI_Recv(&buf[1], 1, MPI_INT, 3, 3, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[2], 1, MPI_INT, 6, 6, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[3], 1, MPI_INT, 11, 11, MPI_COMM_WORLD, &status);

        printf("Step 1: SubRoot Process 7 : %d %d %d %d", buf[0], buf[1], buf[2], buf[3]);

        //printf("BURASI %d %d %d %d BURASI", buf[0], buf[1], buf[2], buf[3]);

        MPI_Send(buf, 4, MPI_INT, 1, 7, MPI_COMM_WORLD);
    }
    else if (rank == 8) {
        buf = (int*)malloc(4 * sizeof(int));
        buf[0] = rank;

        MPI_Recv(&buf[1], 1, MPI_INT, 4, 4, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[2], 1, MPI_INT, 9, 9, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[3], 1, MPI_INT, 12, 12, MPI_COMM_WORLD, &status);

        printf("\nStep 1: SubRoot Process 8 : %d %d %d %d\n", buf[0], buf[1], buf[2], buf[3]);

        //printf("BURASI %d %d %d %d BURASI", buf[0], buf[1], buf[2], buf[3]);

        MPI_Send(buf, 4, MPI_INT, 1, 8, MPI_COMM_WORLD);
    }
    else if (rank == 14) {
        buf = (int*)malloc(4 * sizeof(int));
        buf[0] = rank;

        MPI_Recv(&buf[1], 1, MPI_INT, 10, 10, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[2], 1, MPI_INT, 13, 13, MPI_COMM_WORLD, &status);
        MPI_Recv(&buf[3], 1, MPI_INT, 15, 15, MPI_COMM_WORLD, &status);

        printf("Step 1: SubRoot Process 14 : %d %d %d %d\n", buf[0], buf[1], buf[2], buf[3]);

        //printf("BURASI %d %d %d %d BURASI", buf[0], buf[1], buf[2], buf[3]);

        MPI_Send(buf, 4, MPI_INT, 1, 14, MPI_COMM_WORLD);
    }
    
    /* MPI_Gather(&data, 1, MPI_INT, &arr, 1, MPI_INT, 0, MPI_COMM_WORLD);
    this statement works correct.*/

    /*Below here is my previous codes for learning and applying what i have learned so far.*/
    
    //MPI_Gather(&data, 1, MPI_INT, &arr, 1, MPI_INT, 0, MPI_COMM_WORLD);

    
    /*int commsize, rank;
    MPI_Status status;
    int data = 0;
    int* buf = NULL;
    if (rank == 0) {
        int arr[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        buf = arr;
    }

    printf("data before scatter in each process %d is : %d ", rank, data);*/

    /*MPI_Scatter(buf, 1, MPI_INT, &data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    printf("data AFTER scatter in each process %d is : %d ", rank, data);*/
    /*printf("Before the bcast %d\n", data);

    MPI_Bcast(&data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    printf("After the bcast %d\n", data);*/

    /*if (rank == 0) {
        int x = 10;
        MPI_Send(&x, 1, MPI_INT, 1, 2, MPI_COMM_WORLD);
    }
    else {
        int y;
        MPI_Recv(&y, 1, MPI_INT, 0, 2, MPI_COMM_WORLD, &status);
        printf("%d\n", y);
    }*/

    /*char processor_name[MPI_MAX_PROCESSOR_NAME];
    int name_len;

    MPI_Get_processor_name(processor_name, &name_len);*/

    /*printf("Hello world from processor %s, rank %d out of %d processors\n",
        processor_name, rank, commsize);*/

    //printf("Hello 442 Calisma Odasi");

    MPI_Finalize();

    return 0;
}

/*if (rank == 0) {
        MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    }

    if (rank == 1) {
        buf = (int*)malloc(2 * sizeof(int));
        buf[0] = rank;
        MPI_Recv(&buf[1], 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        printf("%d %d", buf[0], buf[1]);
    }*/


/*
    int gsize,sendarray[100];
    int root, *rbuf;
    ...
    MPI_Comm_size( comm, &gsize);
    rbuf = (int *)malloc(gsize*100*sizeof(int));
    MPI_Gather( sendarray, 100, MPI_INT, rbuf, 100, MPI_INT, root, comm);

*/

/*int MPI_Gather(void* sendbuf, int sendcount, MPI_Datatype senddatatype, void* recvbuf, 
    int recvcount, MPI_Datatype recvdatatype, int target, MPI_Comm comm) {
    
}*/
